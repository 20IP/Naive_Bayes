#!/usr/bin/env python
# coding: utf-8

# In[1]:


from standard_function import *
from sklearn.feature_extraction.text import CountVectorizer


# In[2]:


df = pd.read_excel("dataset_train.xls", header = None, encoding = 'utf-8')


# In[3]:


df1=''
for i in range(0, df.shape[0]):
    df1 += df[0][i][0:3]+ " "


# In[4]:


def Convert(string): 
    li = list(string.split(" ")) 
    return li 
       
df2 = Convert(df1)


# In[5]:


df[3] = pd.Series(df2)


# In[6]:


data_frame = df[[0,2,3]]
data_frame.rename(index=int, columns={0: 0, 2: 1, 3: 2 })
data_frame = data_frame.drop([0])


# In[7]:


target = data_frame[3]
data_frame[2] = data_frame[2].apply(delete_special_char)
data_frame[2] = data_frame[2].apply(revert_text)


# In[8]:


from nltk import ngrams

def kieu_ngram(string, n=1):
    gram_str = list(ngrams(string.split(), n))
    return [ " ".join(gram).lower() for gram in gram_str ]

#data_frame["1gram"] = data_frame[2].apply(lambda t: kieu_ngram(t, 1))
data_frame["2gram"] = data_frame[2].apply(lambda t: kieu_ngram(t, 2))


# In[9]:


train_data = data_frame["2gram"].tolist()


# In[10]:


from gensim.models import Word2Vec
from gensim.test.utils import common_texts, get_tmpfile
import logging

path = get_tmpfile("2_gram.model")
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)    
model = Word2Vec(train_data, size=100, window=10, min_count=1, workers=4, sg=0)
model.save("2_gram.model")

print(" Saved Model !")


# In[11]:


#model.wv.similar_by_word("rối loạn")


# In[ ]:




