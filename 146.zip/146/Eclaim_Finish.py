#!/usr/bin/env python
# coding: utf-8

from sklearn.feature_extraction.text import CountVectorizer
from gensim.test.utils import common_texts, get_tmpfile
from sklearn.model_selection import GridSearchCV
from gensim.models import Word2Vec
from standard_function import *
from return_detail_icd_code import *
import pickle
import unicodedata
from fuzzywuzzy import process
from fuzzywuzzy import fuzz
import pandas as pd
import os


# # Load data, Models and wb File


#load_data_check_default = pd.read_excel("dataset.xls", header = None)
load_data_check_default = pd.read_excel("dataset_train.xls", header = None, encoding = 'utf-8')

load_data_check = load_data_check_default.copy()
load_data_check[2] = load_data_check[2].apply(delete_special_char)

f = open('Eclaim_predict.pickle', 'rb')       # load model dự đoán mã icd 
classifier = pickle.load(f)
f.close()

with open ('sample_vector', 'rb') as fp:
    itemlist = pickle.load(fp)

with open ('exacly_2_word', 'rb') as fp_2:    # Load data về 2 cụm từ 
    words_2 = pickle.load(fp_2)

with open ('exacly_3_word', 'rb') as fp_3:    # Load data về 3 cụm từ
    words_3 = pickle.load(fp_3)

with open('link_words.pkl', 'rb') as f:
    listview = pickle.load(f)

model_2 = Word2Vec.load("2_gram.model")

model_3 = Word2Vec.load("3_gram.model")
 


# # Xử lý đầu vào Input

#text = input("Cung cấp chuỗi cần xác định :")
def output_icd_fs(raw_data_input):

    text = raw_data_input

    text = revert_text(out_special_char(text))    # hàm loại bỏ dấu ngoặc tròn, vuông , \ , /
    pr = spaces_num(char_num(text))    # loại bỏ khoản trắng vô nghĩa  
    pr1 = ' '.join(pr)                 # convert  list to string
    pr1 = delete_special_char(pr1)     # delete others special char --- > string return string


    text1 = pr1.strip("").split(" ")       # Convert str to list
    text1 = spaces_num(text1)                # loại bỏ khoản trắng thừa trong list
    text2 = pr1.strip("").split("*")       # Convert str to list Text 1 chứa list các từ đơn
    text2 = spaces_num(text2)                # Text2 chứa List cả cụm từ
    temp_02 = text1.copy()


    check_logic = True
    if (len(text1) >= 3):
        sta = incorrect_spelling(text1, words_2, words_3)
        text1 = sta.strip(' ').split(' ')
        text2 = sta.strip(' ').split('*')
    elif len(text1) == 2:
        kq = check_incorrect_2_word(text1,words_2)
        text1 = kq[0]
        check_logic = kq[1]
    if len(text1) == 1:
        pass


    new_str =''
    for i in range(0,len(text1)-1):
        new_str += text1[i] + ' ' + text1[i+1] + ","


    new_str = new_str.strip(',').split(",")
    addr = []
    chuoi = ''
    for index,i in enumerate (new_str[:len(new_str)]):
        if try_except_2_gram(i) == False :
            addr.append(index)
            chuoi += i + ","
    if len(text1)-len(addr) == 1:
        addr.append(max(addr)+1)


    if len(addr) == 0:
        addr.append(-1)
    sum_index = addr[0]
    temp = []
    for i in range(0,len(addr) - 1):
        if (addr[i+1] - addr[i]) == 1:
            sum_index = addr[i+1]
        else:
            temp.append(sum_index)
            sum_index = addr[i+1]
    temp.append(sum_index)
    if temp[0] == '':
        temp.append(len(text1))
    else:
        temp = list(set(temp))
        temp.sort(reverse=False)

    check = ''
    emty = ''
    sta = []
    sto = []
    sta1 = []
    for index, x in enumerate(text1):     # cắt chuỗi bệnh thành các loại bệnh bước 1
        if index in temp:
            check += x + ','
        else:
            check += x + ' '
    check = spaces_num(check.strip().split(','))

    if check_logic == False:             # Tách 2 bệnh chỉ có 2 chữ cái
        check = temp_02

    for i in range(0, len(check)):       # Gộp các từ đơn lẻ tránh lỗi Vocabulary
        if len(check[i]) == 1:
            check.remove(check[i])
            break

    for i in range(0, len(check)): 
        if len(check[i]) == 1:
            check[i-1] = check[i-1] + ' ' + check[i]
            check.remove(check[i])
                        
    for i in check:                     # Tách các bệnh dính liền thành các loại bệnh bước 2
        ix = i.split(' ')
        for j in listview:
            if j in i:
                jx = j.split(' ')
                for index, val in enumerate(ix[0:len(ix)-2]):
                    if (ix[index] == jx[0]) and (ix[index+1]==jx[1]) and (try_except_3_gram(j+' '+ix[index+2]) == False):
                        ix.insert(index+1, ',') 
        ix = ' '.join(ix)
        i = ix
        emty += i +','
    check = emty.strip(',').split(',')


    count = CountVectorizer()
    count.fit(itemlist)
    bag_of_words = count.transform(itemlist)


    x_new1 = count.transform(check)
    x_new1
    kq = classifier.predict(x_new1)


    '''
    res1 = ''
    Data2Sam = []
    for g in range(0,len(kq)):
        df_end = (load_data_check[load_data_check[1] == kq[g]])
        io = decission_value_return_02(df_end, check[g].split(','))
        io = list(io)
        io.append(check[g])
        #ii = load_data_check_default[load_data_check_default[0] == io[0]].index.item()
        #res1 += str(io[0]) + ':' + str(io[1]) + ':' + str(io[2]) + ':' +load_data_check_default[1][ii] + '**'
        Data2Sam.append(io)
    '''

    dic_sum = {"Infor":[]}

    for g in range(0,len(kq)):
        df_end = (load_data_check[load_data_check[1] == kq[g]])
        io = decission_value_return_01(df_end, check[g].split(','))
        dic_sum["Infor"].append(io)
    
    return dic_sum


    


'''
import json
with open("Ma_Benh.json", "r") as fp:
    data = json.load(fp)

with open('Ma_Benh.json', 'w', encoding='utf-8') as fp:
    json.dump(dic_sum, fp, ensure_ascii = False, sort_keys = True, indent = 4,)
print(" Save !")
'''





