#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import BernoulliNB, MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from standard_function import *
from return_detail_icd_code import *
import pickle
import unicodedata


# In[2]:


df = pd.read_excel("dataset_train.xls", header = None, encoding = 'utf-8')


# In[3]:


df1=''
for i in range(0, df.shape[0]):
    df1 += df[0][i][0:3]+ " "


# In[4]:


def Convert(string): 
    li = list(string.split(" ")) 
    return li 
       
df2 = Convert(df1)


# In[5]:


df[3] = pd.Series(df2)


# In[6]:


data_frame = df[[0,2,3]]


# In[7]:


target = data_frame[3]


# In[8]:


data_frame[2] = data_frame[2].apply(delete_special_char)
data_frame[2] = data_frame[2].apply(revert_text)
#data_frame.to_excel("data_training.xlsx")
#print("OK")


# In[9]:


feature = data_frame[2]


# In[10]:


text_data = np.array(feature)


# In[11]:


with open('sample_vector', 'wb') as fp:
    pickle.dump(text_data, fp)
print("Save Sample ")


# In[12]:


count = CountVectorizer(decode_error='ignore')
count.fit(text_data)
print(count)
bag_of_words = count.transform(text_data)
bag_of_words


# In[13]:


X = bag_of_words.toarray()


# In[14]:


y = np.array(target)


# In[15]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.1,random_state = 1)


# In[16]:


params = {'alpha':[0.001,0.003,0.005,0.007,0.01,0.015]}
clf = BernoulliNB()
#clf = MultinomialNB()

clf= GridSearchCV(clf, params, cv = 5)
clf.fit(X_train, y_train)
print(clf.best_params_)

best_clf = clf.best_estimator_
y_pred = best_clf.predict(X_test)

print(" training Size = %d, accuracy = %.2f%%" %      (len(X_train), accuracy_score(y_test,y_pred ) *100))


# In[17]:


f = open('Eclaim_predict.pickle', 'wb')
pickle.dump(clf, f)
f.close()
print("Model Saved..")


# In[18]:


loaded_model = pickle.load(open('Eclaim_predict.pickle', 'rb'))
#result = loaded_model.predict(y_test)
#print(result)


# In[19]:


'''
data = ["chốc hoá của các bệnh da khác"]
y_test = count.transform(data)
result = loaded_model.predict(y_test)
result
'''


# In[20]:


'''target = data_frame[3]
data_frame[2] = data_frame[2].apply(delete_special_char)
#data_frame[2] = data_frame[2].apply(un_punctuation)
data_frame[2][4414]
'''


# In[ ]:




