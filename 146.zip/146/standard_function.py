#!/usr/bin/env python
# coding: utf-8

import os
import re
import numpy as np
import pandas as pd
import unicodedata
from fuzzywuzzy import fuzz
from gensim.models import Word2Vec

model_2 = Word2Vec.load(os.getcwd()+"/2_gram.model")


#********************************************************************************* HÀM XÓA VÀ THAY THẾ NHỮNG KÝ TỰ ĐẶC BIỆT ******************************************************



def revert_text(row):
    row = row.replace("type", "typ").replace("amidam", "amydan").replace("amydal", "amydan").replace("amiđan", "amydan").replace("amidam", "amydan")
    return row

#********************************************************************************* HÀM XÓA VÀ THAY THẾ NHỮNG KÝ TỰ ĐẶC BIỆT ******************************************************

def delete_special_char(row):    
    row = row.replace("V.A", "va1")
    row = row.replace(",", " ").replace(".", " ")        .replace(";", " ").replace("“", " ")         .replace(":", " ").replace("”", " ")         .replace('"', " ").replace("'", " ")         .replace("!", " ").replace("?", " ")         .replace("*", " ").replace("&", " ")         .replace("(", " ").replace(")", " ")         .replace("†", " ").replace("[", " ")         .replace("]", " ").replace("–", " ")         .replace("-", " ").replace("%", " ")         .replace("@", " ").replace("^", " ")         .replace("/", " ").replace("+", " ").replace(",", " ")        .lower()
    
    row = row.strip()
    return row

#********************************************************************************* HÀM THAY THẾ DẤU CÂU - CÁC THANH SẮC ******************************************************


def un_punctuation(text):
    patterns = {
        #'[ă]':'aw',          # chars a
        #'[â]':'aa',
        '[ấ,ầ,ẩ,ẫ,ậ]':'â',
        '[ắ,ằ,ẳ,ẵ,ặ]':'ă',
        '[á,à,ả,ã,ạ]':'a',
                 
        #'[đ]': 'dd',          # char d
        #'[ê]': 'ee',          # chars e
        '[ế,ề,ể,ễ,ệ]': 'ê',
        '[é,è,ẻ,ẽ,ẹ]': 'e',
        
        '[ớ,ờ,ở,ỡ,ợ]': 'ơ',
        '[ố,ồ,ổ,ỗ,ộ]': 'ô',
        '[ó,ò,ỏ,õ,ọ]': 'o',
       #'[ô]': 'ô',
       # '[ơ]': 'ow',
        '[ổ]': 'ô',
        '[ố]': 'ô',
        '[ở]': 'ơ',
        '[ỏ]': 'o',
        '[ỡ]': 'ơ',
        '[õ]': 'o',
        
        '[ỉ,ì,ị,ĩ,í]': 'i',
        
        '[ý,ỷ,ỵ,ỳ,ỹ]': 'y',
        
        '[ữ,ử,ự,ứ,ừ]': 'ư',
        '[ụ,ù,ủ,ú,ũ]': 'u',
        
          } 
    output =text
    for reget, replace in patterns.items():
        output = re.sub(reget, replace, output)
        output = re.sub(reget.lower(), replace.lower(), output)
    return output


#********************************************************************************* HÀM XÓA NHỮNG SPACE TRONG LIST ******************************************************


def spaces_num(string:list):
    new_string = []
    for i in string:
        if i!="":
            new_string.append(i)
    return new_string
    
#********************************************************************************* HÀM XÓA NHỮNG MÃ ICD_10 CODE KHÔNG NGOẠI TRỪ VITAMIN B ******************************************************

def char_num(data : str):
    data = data.lower()
    a1 = data.replace("(", " ").replace(")", " ").replace("]", " ").replace("[", " ").replace("/", " ").replace("\\", " ")
    a2 = a1.split(' ')
    for index, i in enumerate(a2):
        if (len(i)>=2) and (i[1].isnumeric() == True) and (i[0] != 'b'):
            a2[index] = ''
    return a2


#********************************************************************************* HÀM THAY THẾ TÊN GỌI ĐẶC BIỆT CÓ THỂ BỊ MẤT KHI THỰC HIỆN COUNVECTORSIZER *****************************************************


def out_special_char(row):    
    row = row.replace("V.A", "va1").replace("VA", "va1")
    row = row.strip()
    return row


#********************************************************************************* HÀM SỬA LỖI CHÍNH TẢ ĐẦU VÀO LÀ 1 LIST ******************************************************


def incorrect_spelling(chuoi_str:list , words_2, words_3):
    t = ''
    x = ''
    t2 = []
    t3 = []
    mil = len(chuoi_str)
    for i in range(0,mil-2):
        t = chuoi_str[i] + ' ' + chuoi_str[i+1]
        x = chuoi_str[i] + ' ' + chuoi_str[i+1] + ' ' + chuoi_str[i+2]
        if try_except_2gram(t) == False:
            t1 = re_2_words(t, words_2)
            x1 = re_3_words(x, words_3)
            t11 = ''.join(t1)
            x11 = ''.join(x1)
            if (t11 in x11) == True:
                t2 = ''.join(t1).split(' ')
                chuoi_str[i] = t2[0]
                chuoi_str[i+1] = t2[1]
                chuoi_str = chuoi_str

    t = chuoi_str[mil-2] + ' ' + chuoi_str[mil-1]
    x = chuoi_str[mil-3] + ' ' + chuoi_str[mil-2] + ' ' + chuoi_str[mil-1]
    if try_except_2gram(t) == False:
        t1 = re_2_words(t, words_2)
        x1 = re_3_words(x, words_3)
        t11 = ''.join(t1)
        x11 = ''.join(x1)
        if (t11 in x11) == True:
            t2 = ''.join(t1).split(' ')
            chuoi_str[mil-2] = t2[0]
            chuoi_str[mil-1] = t2[1]
            chuoi_str = chuoi_str

    chuoi_str_cplt = ' '.join(chuoi_str)
    return chuoi_str_cplt

#********************************************************************************* HÀM SỬA LỖI CHÍNH TẢ ĐẦU VÀO LÀ 1 LIST 2 tu  ******************************************************


def check_incorrect_2_word(chuoi_lst:list , words_2):
    copy_2 = chuoi_lst.copy()
    status = False
    chuoi_lst_cplt = []
    t=''
    t = copy_2[0] + ' ' + copy_2[1]
    t2 = []
    if try_except_2_gram(t) == False:
        t1 = re_2_words(t, words_2)
        t2 = ''.join(t1).split(' ')
        copy_2[0] = t2[0]
        copy_2[1] = t2[1]
    copy_2 = copy_2
    chuoi_lst_01 = ' '.join(copy_2)
    if try_except_2_gram(chuoi_lst_01) == True:
        chuoi_lst_cplt = chuoi_lst_01.split(' ')
        status = True
    else:
        chuoi_lst_cplt = chuoi_lst
        status = False

    return chuoi_lst_cplt, status



#********************************************************************************* HÀM TRẢ VỀ  2 KÝ CỤM TỪ GẦN NHẤT SO VỚI INPUT ******************************************************

def re_2_words(st:str , seri):
    gg=[]
    fg=[]
    for i in range(0,len(seri)):
        Ratio = fuzz.ratio(st,seri[i])
        gg.append(Ratio)
        fg.append(seri[i])
    temp2 = pd.DataFrame(gg,fg)
    temp2 = temp2.sort_values(by = [0],ascending=False)
    two_words = temp2[0:1]
    return two_words.index.values


#********************************************************************************* HÀM TRẢ VỀ  3 KÝ CỤM TỪ GẦN NHẤT SO VỚI INPUT ******************************************************


def re_3_words(st:str , seri):
    gg=[]
    fg=[]
    for i in range(0,len(seri)):
        Ratio = fuzz.ratio(st,seri[i])
        gg.append(Ratio)
        fg.append(seri[i])
    temp2 = pd.DataFrame(gg,fg)
    temp2 = temp2.sort_values(by = [0],ascending=False)
    thr_words = temp2[0:1]
    return thr_words.index.values


#********************************************************************************* HÀM XỬ LÝ NGOẠI LỆ CẮT 2 TỪ ******************************************************


def try_except_2gram ( string):               
    try :  
        model.wv.similar_by_word(string)
    except :
        kq = False
    else :
        kq = True
    return kq


#********************************************************************************* HÀM XỬ LÝ NGOẠI LỆ CẮT 3 TỪ ******************************************************


def try_except_3gram ( string):               
    try :  
        model.wv.similar_by_word(string)
    except :
        kq = False
    else :
        kq = True
    return kq



def try_except_2_gram ( string):
    model_2 = Word2Vec.load("2_gram.model")
    try :  
        model_2.wv.similar_by_word(string)
    except :
        kq = False
    else :
        kq = True
    return kq


def try_except_3_gram ( string):
    try :  
        model_3.wv.similar_by_word(string)
    except :
        kq = False
    else :
        kq = True
    return kq