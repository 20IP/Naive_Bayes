#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import re
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from fuzzywuzzy import fuzz



def decission_value_return_01(data_frame: pd.core.frame.DataFrame, find_acc : list):
    # Truyền 1 DataFrame với 2 Cols .... Không giới hạn Index row
    df = data_frame[2]
    temp = 0
    num_temp = 0
    score = 0
    fol_dataframe = []
    fol_inputlist = []
    final = []
    convert = ''.join(find_acc)
    convert_input = convert.strip().split(' ')
    for k in convert_input:
        if k != '':
            fol_inputlist.append(k)
    
    for index, i in enumerate(df):
        f = fuzz.ratio(convert.lower(), i.lower()) # tinh diem fuzzy
        if f > temp:
            temp = f
            num_temp = index       # Lay index cua desc co so diem cao nhat
        else : pass
            
    str_dataframe =  data_frame.iat[num_temp,2].lower()    # lay description tuong ung voi index 
    lis_dataframe = str_dataframe.strip().split(' ')
    for j in lis_dataframe:
        if j != '':
            fol_dataframe.append(j)
    temp = temp / 100         
    common = set(fol_inputlist) & set(fol_dataframe)

    if len(common) == 0 or temp < 0.3:
        score_x = 0
    else:
        score = round(len(common)/len(fol_inputlist),2)
        score_x = round((score+temp)/2,2)
    
    final = [data_frame.iat[num_temp,0], score_x, data_frame.iat[num_temp,2]]
    return final



def decission_value_return_02(data_frame: pd.core.frame.DataFrame, find_acc : list):
    # Truyền 1 DataFrame với 2 Cols .... Không giới hạn Index row
    index = data_frame.shape[0]                             # Lấy index row
    #*******************************************************************************************
    t=0
    kq=''
    for i in range(0, index):                               
        df1 = data_frame.iat[i,1]                                                         
        df1 = df1.split(',') 
        vectorizer = CountVectorizer()                          
        vectorizer.fit(df1)                                  
        axis_sample_df1 = vectorizer.transform(df1)        
        axis_1 = axis_sample_df1.toarray()
        len_arr = axis_1.shape[1]
        axis_sample_find_acc = vectorizer.transform(find_acc)
        axis_2 = axis_sample_find_acc.toarray()
        for j in range(0,len_arr):                            
            if axis_2[0][j] !=0:
                t +=1
        kq += str(t/len_arr) + " "                          
        t = 0
    oc = kq.strip(' ').split(" ")
    
    #*******************************************************************************************
    
    for k in range(0, len(oc)):
        oc[k] = eval(oc[k])                  # Chuyển đổi giá trị str trong list sang số
        
    max_val = max(oc)

    #*******************************************************************************************
    
    k = 0
    kq1 =0
    p = 0
    for k in range(0, len(oc)):
        if oc[k] == max_val:
            kq1 +=1
            p = k
            
    if kq1 > 1:
        add_index = data_frame.iat[0,0] 
        add_value = data_frame.iat[0,2]
    else :
        add_index = data_frame.iat[p,0] 
        add_value = data_frame.iat[p,2]
 
    return add_index, max_val, kq1




