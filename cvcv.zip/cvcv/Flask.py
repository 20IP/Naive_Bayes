from flask import Flask
from flask import json
from flask import Response, request, redirect, url_for
from Eclaim_Finish import *
import requests
from flask_restful import reqparse, abort, Api, Resource

app = Flask(__name__)
api = Api(app)

def analysis_ocr (data):
    #print(data)
    a = data["Desc"]
    return output_icd_fs(a) #print(data)

class OCRData(Resource):
    def post(self):
        json_data = request.get_json(force=True)
        result = analysis_ocr(json_data)
        resp = Response(json.dumps(result, ensure_ascii=False).encode('utf8'), status=200, mimetype='application/json')
        resp.headers['charset'] = 'utf-8'
        return result, 200

api.add_resource(OCRData, '/analysis-ocr')

if __name__ == '__main__':
    app.run(host = '0.0.0.0',port=5000, debug=True)