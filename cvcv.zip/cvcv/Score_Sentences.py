#!/usr/bin/env python
# coding: utf-8

# In[1]:


from standard_function import *
from sklearn.feature_extraction.text import CountVectorizer
from fuzzywuzzy import fuzz
from gensim.models import Word2Vec
from standard_function import *
from fuzzywuzzy import process


# In[2]:


df = pd.read_excel("dataset_train.xls", header = None, encoding = 'utf-8')


# In[3]:


df1=''
for i in range(0, df.shape[0]):
    df1 += df[0][i][0:3]+ " "


# In[4]:


def Convert(string): 
    li = list(string.split(" ")) 
    return li 
       
df2 = Convert(df1)


# In[5]:


df[3] = pd.Series(df2)


# In[6]:


data_frame = df[[0,2,3]]
data_frame.rename(index = int, columns = {0: 0, 2: 1, 3: 2 })
data_frame = data_frame.drop([0])


# In[7]:


target = data_frame[3]
data_frame[2] = data_frame[2].apply(delete_special_char)
data_frame[2] = data_frame[2].apply(revert_text)


# In[8]:


text=''
for i in range(1, data_frame.shape[0]):
    text += data_frame[2][i] + ' '


# In[9]:


from nltk import ngrams

def kieu_ngram_2(string, n=2):
    gram_str = list(ngrams(string.split(), n))
    return [ " ".join(gram).lower() for gram in gram_str ]
text_02 = kieu_ngram_2(text,2)
a = list(set(text_02))

import pickle
with open('exacly_2_word', 'wb') as fp:
    pickle.dump(a, fp)

print('Saved !')


# In[10]:


from nltk import ngrams

def kieu_ngram_3(string, n = 3):
    gram_str = list(ngrams(string.split(), n))
    return [ " ".join(gram).lower() for gram in gram_str ]
text_02 = kieu_ngram_3(text,3)
a = list(set(text_02))

import pickle
with open('exacly_3_word', 'wb') as fp:
    pickle.dump(a, fp)

print('Saved !')


# In[11]:


#with open ('exacly_2_word', 'rb') as fp_2:    # Load data về 2 cụm từ 
#    words_2 = pickle.load(fp_2)
#t1 = re_2_words('trùng mu', words_2)
#t1



# In[13]:


'''
with open ('exacly_3_word', 'rb') as fp_3:    # Load data về 2 cụm từ 
    words_3 = pickle.load(fp_3)
t1 = re_2_words('khác viêm dạ', words_3)
t1
'''


# In[ ]:




