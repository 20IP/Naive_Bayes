#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pickle


# In[2]:


#link_words = ["khác viêm","khác các","virus gây","virus viêm","mạn viêm","cấp viêm","sởi xơ","hiệu viêm"]


# In[3]:


def pre(word):ICD_new
    word = word.lower().strip(' ').split('*')
    return word


# In[4]:


new_str = input("Thêm từ liên kết hoặc Nhập 'Q' để kết thúc :")
while new_str != 'q':
    link_words = link_words + pre(new_str)
    new_str = input("Thêm từ liên kết hoặc Nhập 'Q' để kết thúc :")
    print("Đã lưu từ vào dữ liệu !")
print("Đã kết thúc khởi tạo dữ liệu !")


# In[5]:


with open('link_words.pkl', 'wb') as f:
    pickle.dump(link_words, f)


# In[6]:


with open('link_words.pkl', 'rb') as f:
    listview = pickle.load(f)
listview


# In[ ]:




