#!/usr/bin/env python
# coding: utf-8

# In[1]:


import re
import numpy as np
import pandas as pd
import unicodedata


# In[2]:


def delete_special_char(row):    
    row = row.replace("V.A", "va1")
    row = row.replace(",", " ").replace(".", " ")        .replace(";", " ").replace("“", " ")         .replace(":", " ").replace("”", " ")         .replace('"', " ").replace("'", " ")         .replace("!", " ").replace("?", " ")         .replace("*", " ").replace("&", " ")         .replace("(", " ").replace(")", " ")         .replace("†", " ").replace("[", " ")         .replace("]", " ").replace("–", " ")         .replace("-", " ").replace("%", " ")         .replace("@", " ").replace("^", " ")         .replace("/", " ").replace("+", " ").replace(",", " ")        .lower()
    
    row = row.strip()
    return row


# In[3]:


def un_punctuation(text):
    patterns = {
        #'[ă]':'aw',          # chars a
        #'[â]':'aa',
        '[ấ,ầ,ẩ,ẫ,ậ]':'â',
        '[ắ,ằ,ẳ,ẵ,ặ]':'ă',
        '[á,à,ả,ã,ạ]':'a',
                 
        #'[đ]': 'dd',          # char d
        #'[ê]': 'ee',          # chars e
        '[ế,ề,ể,ễ,ệ]': 'ê',
        '[é,è,ẻ,ẽ,ẹ]': 'e',
        
        '[ớ,ờ,ở,ỡ,ợ]': 'ơ',
        '[ố,ồ,ổ,ỗ,ộ]': 'ô',
        '[ó,ò,ỏ,õ,ọ]': 'o',
       #'[ô]': 'ô',
       # '[ơ]': 'ow',
        '[ổ]': 'ô',
        '[ố]': 'ô',
        '[ở]': 'ơ',
        '[ỏ]': 'o',
        '[ỡ]': 'ơ',
        '[õ]': 'o',
        
        '[ỉ,ì,ị,ĩ,í]': 'i',
        
        '[ý,ỷ,ỵ,ỳ,ỹ]': 'y',
        
        '[ữ,ử,ự,ứ,ừ]': 'ư',
        '[ụ,ù,ủ,ú,ũ]': 'u',
        
          } 
    output =text
    for reget, replace in patterns.items():
        output = re.sub(reget, replace, output)
        output = re.sub(reget.lower(), replace.lower(), output)
    return output


# In[4]:


def spaces_num(string:list):
    new_string = []
    for i in string:
        if i!="":
            new_string.append(i)
    return new_string
    


def char_num(data : str):
    data = data.lower()
    a1 = data.replace("(", " ").replace(")", " ").replace("]", " ").replace("[", " ").replace("/", " ").replace("\\", " ")
    #a2 = un_punctuation(a1)
    a2 = a1.split(' ')
    for index, i in enumerate(a2):
        if (len(i)>=2) and (i[1].isnumeric() == True) and (i[0] != 'b'):
            a2[index] = ''
    return a2


def out_special_char(row):    
    row = row.replace("V.A", "va1").replace("VA", "va1")
    row = row.strip()
    return row


