#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import re
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer


# In[2]:


def decission_value_return_01(data_frame: pd.core.frame.DataFrame, find_acc : list):
    # Truyền 1 DataFrame với 2 Cols .... Không giới hạn Index row
    
    vectorizer = CountVectorizer()                          # Lệnh gọi CountVector
    vectorizer.fit(find_acc)                                # App vào list find_acc
    axis_find_acc = vectorizer.transform(find_acc)          # Chuẩn hóa List và chuyển đổi type của vectorizer
    axis_1 = axis_find_acc.toarray()                        # Chuyển về Vector 2 Chiều
    len_arr = axis_1.shape[1]                               # Lấy độ dài Vector
    index = data_frame.shape[0]                             # Lấy index row của dữ liệu data frame
    
    #*******************************************************************************************
    
    kq = ''                                                   #
    kq1 = 0                                                   #
    t=0
    for i in range(0, index):                                 # Duyệt từng value index col[1]
        df1 = data_frame.iat[i,1]                             # Lấy mỗi giá trị của cols type str
        df1 = df1.split(',')                                  # Convet str to matrix list 1D
        axis_sample_string = vectorizer.transform(df1)        # Convert Vector with sample find_acc
        axis_2 = axis_sample_string.toarray()                 # Change to array
        for j in range(0,len_arr):                            # Compare value of matrix 1D
            if axis_2[0][j] !=0:
                t +=1
        kq += str(t/len_arr) + " "                            # Export values
        t = 0
    oc = kq.strip(' ').split(" ")
    
    #*******************************************************************************************
    
    for k in range(0, len(oc)):
        oc[k] = eval(oc[k])
    max_val = max(oc)

    #*******************************************************************************************
    
    p = 0
    for k in range(0, len(oc)):
        if oc[k] == max_val:
            kq1 +=1;                    # Đếm xem có bao nhieu giá trị max
            p = k                       # 
            
    if kq1 > 1:
        add_index = data_frame.iat[0,0] 
        add_value = data_frame.iat[0,1]
    else :
        add_index = data_frame.iat[p,0] 
        add_value = data_frame.iat[p,1]
 
    return add_index, max_val, kq1


# In[3]:


def decission_value_return_02(data_frame: pd.core.frame.DataFrame, find_acc : list):
    # Truyền 1 DataFrame với 2 Cols .... Không giới hạn Index row
    index = data_frame.shape[0]                             # Lấy index row
    #*******************************************************************************************
    t=0
    kq=''
    for i in range(0, index):                               
        df1 = data_frame.iat[i,1]                                                         
        df1 = df1.split(',') 
        vectorizer = CountVectorizer()                          
        vectorizer.fit(df1)                                  
        axis_sample_df1 = vectorizer.transform(df1)        
        axis_1 = axis_sample_df1.toarray()
        len_arr = axis_1.shape[1]
        axis_sample_find_acc = vectorizer.transform(find_acc)
        axis_2 = axis_sample_find_acc.toarray()
        for j in range(0,len_arr):                            
            if axis_2[0][j] !=0:
                t +=1
        kq += str(t/len_arr) + " "                          
        t = 0
    oc = kq.strip(' ').split(" ")
    
    #*******************************************************************************************
    
    for k in range(0, len(oc)):
        oc[k] = eval(oc[k])                  # Chuyển đổi giá trị str trong list sang số
        
    max_val = max(oc)

    #*******************************************************************************************
    
    k = 0
    kq1 =0
    p = 0
    for k in range(0, len(oc)):
        if oc[k] == max_val:
            kq1 +=1;
            p = k
            
    if kq1 > 1:
        add_index = data_frame.iat[0,0] 
        add_value = data_frame.iat[0,1]
    else :
        add_index = data_frame.iat[p,0] 
        add_value = data_frame.iat[p,1]
 
    return add_index, max_val, kq1



